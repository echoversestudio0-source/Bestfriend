package com.friend.ai

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

// Model name: Google AI Studio theke dekhe nao current free model ta.
const val MODEL = "gemini-2.5-flash"
const val DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.appdata"
const val PERSONA = """Tumi amar bestfriend, naam Bondhu. Amar sathe bondhur moto warm, 
mojar, ar sotti kotha bolo. Ami je bhasay likhi (Bangla/Banglish/English) sei bhasay uttor dao. 
Uttor chhoto rakho, jeno kotha bolar moto lage. Amar ager kotha ar memory mone rekho. 
Bhul korle ba kharap decision nile bondhur moto sotti ta bole dao, shudhu haan-te-haan milio na."""

class MainActivity : ComponentActivity() {
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var tts: TextToSpeech
    private var history = JSONArray()
    private var account: android.accounts.Account? = null
    private var driveFileId: String? = null
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    private val signIn = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        GoogleSignIn.getSignedInAccountFromIntent(r.data)
            .addOnSuccessListener { account = it.account; show("[Drive connected]"); loadMemory() }
            .addOnFailureListener { show("[Drive login failed: ${it.message}]") }
    }
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!t.isNullOrBlank()) send(t)
    }
    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listen() }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        tts = TextToSpeech(this) { tts.language = Locale.getDefault() }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK); setPadding(32, 64, 32, 32) }
        val title = TextView(this).apply { text = "B O N D H U"; setTextColor(Color.CYAN); textSize = 26f; gravity = Gravity.CENTER }
        log = TextView(this).apply { setTextColor(Color.rgb(120, 230, 255)); textSize = 16f }
        scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply { hint = "Likho..."; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val sendB = Button(this).apply { text = "Send"; setOnClickListener { val t = input.text.toString(); if (t.isNotBlank()) { input.setText(""); send(t) } } }
        val mic = Button(this).apply { text = "🎤 Kotha bolo"; setOnClickListener { micPerm.launch(android.Manifest.permission.RECORD_AUDIO) } }
        val drive = Button(this).apply { text = "Google Drive connect"; setOnClickListener { connectDrive() } }
        root.addView(title)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        listOf(input, sendB, mic, drive).forEach { root.addView(it) }
        setContentView(root)
        if (prefs.getString("key", "").isNullOrBlank()) askKey()
        GoogleSignIn.getLastSignedInAccount(this)?.let { account = it.account; loadMemory() }
    }

    private fun askKey() {
        val e = EditText(this)
        AlertDialog.Builder(this).setTitle("Gemini API key dao (aistudio.google.com theke free)")
            .setView(e).setCancelable(false)
            .setPositiveButton("Save") { _, _ -> prefs.edit().putString("key", e.text.toString().trim()).apply() }.show()
    }

    private fun connectDrive() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail().requestScopes(Scope(DRIVE_SCOPE)).build()
        signIn.launch(GoogleSignIn.getClient(this, gso).signInIntent)
    }

    private fun listen() {
        speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        })
    }

    private fun show(t: String) = runOnUiThread { log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun add(role: String, text: String) {
        history.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
        while (history.length() > 60) history.remove(0)
        while (history.length() > 0 && history.getJSONObject(0).getString("role") != "user") history.remove(0)
    }

    private fun send(text: String) {
        show("Tumi: $text")
        add("user", text)
        Thread {
            try {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", PERSONA))))
                    .put("contents", history)
                val res = http("POST",
                    "https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=${prefs.getString("key", "")}",
                    null, body.toString(), "application/json")
                val reply = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                add("model", reply)
                show("Bondhu: $reply")
                runOnUiThread { tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "r") }
                saveMemory()
            } catch (e: Exception) { show("[Error: ${e.message}]") }
        }.start()
    }

    private fun token() = GoogleAuthUtil.getToken(this, account!!, "oauth2:$DRIVE_SCOPE")

    private fun findFile(tok: String): String? {
        val q = URLEncoder.encode("name='memory.json'", "UTF-8")
        val r = JSONObject(http("GET", "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=$q&fields=files(id)", tok))
        return r.getJSONArray("files").optJSONObject(0)?.getString("id")
    }

    private fun loadMemory() = Thread {
        try {
            val tok = token()
            driveFileId = findFile(tok)
            driveFileId?.let {
                history = JSONArray(http("GET", "https://www.googleapis.com/drive/v3/files/$it?alt=media", tok))
                show("[Ager ${history.length()} ta kotha mone porche]")
            }
        } catch (e: Exception) { show("[Memory load error: ${e.message}]") }
    }.start()

    private fun saveMemory() {
        if (account == null) return
        try {
            val tok = token()
            val data = history.toString()
            if (driveFileId == null) {
                val b = "xx"
                val meta = JSONObject().put("name", "memory.json").put("parents", JSONArray().put("appDataFolder"))
                val body = "--$b\r\nContent-Type: application/json\r\n\r\n$meta\r\n--$b\r\nContent-Type: application/json\r\n\r\n$data\r\n--$b--"
                driveFileId = JSONObject(http("POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id",
                    tok, body, "multipart/related; boundary=$b")).getString("id")
            } else {
                http("PATCH", "https://www.googleapis.com/upload/drive/v3/files/$driveFileId?uploadType=media", tok, data, "application/json")
            }
        } catch (e: Exception) { show("[Drive save error: ${e.message}]") }
    }

    private fun http(method: String, url: String, tok: String?, body: String? = null, type: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = if (method == "PATCH") "POST" else method
        if (method == "PATCH") c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
        tok?.let { c.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) { c.doOutput = true; c.setRequestProperty("Content-Type", type); c.outputStream.use { it.write(body.toByteArray()) } }
        val stream = if (c.responseCode < 400) c.inputStream else c.errorStream
        val out = stream.bufferedReader().readText()
        if (c.responseCode >= 400) throw Exception("HTTP ${c.responseCode}: $out")
        return out
    }
}
